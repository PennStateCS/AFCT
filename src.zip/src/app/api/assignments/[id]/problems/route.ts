// /src/app/api/assignments/[id]/problems

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { verifyToken } from '@/app/utils/jwt';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const assignmentId = params.id;

  try {
    // Extract the Bearer token from the Authorization header
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.split(' ')[1];

    if (!token) {
      return NextResponse.json({ error: 'Missing token' }, { status: 401 });
    }

    let decoded;
    try {
      decoded = verifyToken(token);
    } catch (err: any) {
      console.error('Invalid or expired token:', err);
      return NextResponse.json({ error: 'Invalid or expired token' }, { status: 401 });
    }

    // Fetch the assignment to get courseId
    const assignment = await prisma.assignment.findUnique({
      where: { id: assignmentId },
      select: { courseId: true },
    });

    if (!assignment) {
      return NextResponse.json({ error: 'Assignment not found' }, { status: 404 });
    }

    const userRole = decoded.role;
    const userId = decoded.id;
    const courseId = assignment.courseId;

    // Role-based access control using roster model
    if (userRole === 'STUDENT') {
      const enrollment = await prisma.roster.findFirst({
        where: {
          courseId,
          userId,
          role: 'STUDENT', // You can omit this line to check for any enrollment
        },
      });

      if (!enrollment) {
        return NextResponse.json({ error: 'You are not enrolled in this course' }, { status: 403 });
      }
    } else if (!['FACULTY', 'TA', 'ADMIN'].includes(userRole)) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    }

    // Fetch all problems linked to the assignment
    const assignmentProblems = await prisma.assignmentProblem.findMany({
      where: { assignmentId },
      include: {
        problem: {
          select: {
            id: true,
            title: true,
            description: true,
            type: true,
            maxStates: true,
            isDeterministic: true,
          },
        },
      },
      orderBy: { problemId: 'asc' },
    });

    const problems = assignmentProblems.map((ap) => ap.problem);

    const ip =
      req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
      req.headers.get('x-real-ip') ||
      'unknown';

    await prisma.activityLog.create({
      data: {
        userId,
        action: 'VIEW_ASSIGNMENT_PROBLEMS',
        metadata: { assignmentId, courseId, ipAddress: ip },
      },
    });

    return NextResponse.json(problems);
  } catch (error) {
    console.error('API GET PROBLEMS error:', error);
    return NextResponse.json({ error: 'Failed to fetch problems' }, { status: 500 });
  }
}
