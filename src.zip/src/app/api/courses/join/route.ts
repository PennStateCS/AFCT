/**
 * Course Join API
 *
 * Responsibilities:
 * - Accept a 6-character registration code
 * - Validate course visibility (published + not archived)
 * - Prevent duplicate enrollment
 * - Create a roster entry as STUDENT
 *
 * Notes:
 * - Admins cannot join courses via this route.
 * - Unpublished/archived courses are masked as "not found".
 */

import { auth } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { NextResponse } from 'next/server';
import { createEnhancedActivityLog } from '@/lib/activity-log-utils';
import { logError } from '@/lib/api/activity';
import { isAdmin } from '@/lib/permissions';
import { parseValidDate } from '@/lib/date';

/**
 * Enrolls the signed-in user in a course via its 6-character registration code,
 * as a STUDENT. Users never learn that an unpublished/archived course exists
 * (masked as 404). Global admins can't self-enroll, and the registration window
 * must be open.
 * @openapi
 * summary: Join a course by registration code
 * requestBody:
 *   required: true
 *   content:
 *     application/json:
 *       schema:
 *         type: object
 *         required: [code]
 *         properties:
 *           code: { type: string, description: 6-character course registration code }
 * responses:
 *   200:
 *     description: Joined; returns a message and the course.
 *   400: { description: "Invalid code, admin join attempt, already enrolled, or registration not open." }
 *   401: { description: Not signed in. }
 *   404: { description: "Course not found (also returned for unpublished/archived courses)." }
 *   500: { description: Server error. }
 */
export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user || session.user.inactive) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const { code } = await req.json();
  if (!code || code.length !== 6) {
    return NextResponse.json({ error: 'Invalid course code' }, { status: 400 });
  }

  const course = await prisma.course.findUnique({
    where: { regCode: code.toUpperCase() },
  });

  if (!course) {
    return NextResponse.json({ error: 'Course not found' }, { status: 404 });
  }

  const userId = session.user.id;

  const existing = await prisma.roster.findUnique({
    where: {
      courseId_userId: {
        courseId: course.id,
        userId,
      },
    },
  });

  if (!course.isPublished || course.isArchived) {
    // Do not reveal that an unpublished/archived course exists; say it does not exist.
    return NextResponse.json({ error: 'Course not found' }, { status: 404 });
  }

  if (isAdmin(session.user)) {
    return NextResponse.json({ error: 'Admins cannot register for courses' }, { status: 400 });
  }

  if (existing) {
    return NextResponse.json(
      { error: `You are already registered for this course as ${existing.role}` },
      { status: 400 },
    );
  }

  const registrationOpenAt = parseValidDate(course.registrationOpenAt);
  const registrationCloseAt = parseValidDate(course.registrationCloseAt);

  if (!registrationOpenAt || !registrationCloseAt) {
    return NextResponse.json(
      { error: 'Registration is currently closed for this course.' },
      { status: 400 },
    );
  }

  const now = Date.now();
  if (now < registrationOpenAt.getTime()) {
    return NextResponse.json(
      { error: 'Registration is not open yet for this course.' },
      { status: 400 },
    );
  }

  if (now > registrationCloseAt.getTime()) {
    return NextResponse.json({ error: 'Registration is closed for this course.' }, { status: 400 });
  }

  // Create roster entry
  try {
    await prisma.roster.create({
      data: {
        courseId: course.id,
        userId,
        role: 'STUDENT', // self-service join always enrolls as a student
      },
    });

    await createEnhancedActivityLog(prisma, req, {
      userId,
      action: 'COURSE_JOINED',
      severity: 'INFO',
      category: 'COURSE',
      courseId: course.id,
      metadata: {
        userId,
        courseId: course.id,
        courseCode: course.code,
        courseName: course.name,
        role: 'STUDENT',
      },
    });
  } catch (error) {
    console.error('POST /api/courses/join error:', error);
    await logError(req, {
      userId,
      action: 'COURSE_JOIN_ERROR',
      error,
      category: 'COURSE',
    });
    return NextResponse.json({ error: 'Failed to join the course.' }, { status: 500 });
  }

  const message = `You have successfully joined ${course.name} as a Student.`;

  return NextResponse.json({ success: true, message, course });
}
