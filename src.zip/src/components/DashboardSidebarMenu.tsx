'use client';

// FIXME

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { toast } from 'sonner';

import { cn } from '@/lib/utils';
import { apiPaths } from '@/lib/api-paths';
import { safeSignOut } from '@/lib/safe-signout';
import { getCourseDateBucket } from '@/lib/course-status';

import { ChangePasswordDialog } from './dialogs/ChangePasswordDialog';
import { EditProfileDialog } from './dialogs/EditProfileDialog';

import {
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from '@/components/ui/sidebar';

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

import {
  Calendar,
  Library,
  Book,
  Users,
  UserRound,
  Layers,
  LogOut,
  Logs,
  LockKeyhole,
  UserPen,
  ChevronUp,
  Activity,
  Settings,
  Wrench,
} from 'lucide-react';

const menuButtonStyles =
  'text-sidebar-foreground hover:bg-secondary focus-visible:bg-secondary active:bg-secondary data-[active=true]:bg-secondary data-[active=true]:text-secondary-foreground';

type Course = {
  id: string;
  name: string;
  code: string;
  isPublished: boolean;
  isArchived: boolean;
  startDate: string;
  endDate: string;
};

// The dated sidebar course sections, in display order. Archived courses are
// excluded (they live on the Archived Courses page); each section is hidden when
// it has no courses, and courses within a section are alphabetized by code.
const COURSE_SECTIONS = [
  { bucket: 'upcoming', label: 'Upcoming Courses' },
  { bucket: 'current', label: 'Current Courses' },
  { bucket: 'past', label: 'Past Courses' },
] as const;

// Static admin menu items (kept alphabetical by title)
const adminMenu = [
  { title: 'Courses', url: '/dashboard/courses', icon: Book },
  { title: 'Submission Logs', url: '/dashboard/submissions', icon: Layers },
  { title: 'System Logs', url: '/dashboard/system-logs', icon: Logs },
  { title: 'System Settings', url: '/dashboard/system-settings', icon: Settings },
  { title: 'System Status', url: '/dashboard/system-status', icon: Activity },
  { title: 'User Accounts', url: '/dashboard/users', icon: Users },
];

export default function DashboardSidebarMenu() {
  const pathname = usePathname();
  const { data: session } = useSession();
  const [changePasswordOpen, setChangePasswordOpen] = useState(false);
  const [editProfileOpen, setEditProfileOpen] = useState(false);

  // Cached courses list for sidebar nav, fetched client-side and revalidated.
  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ['courses', 'nav'],
    queryFn: async () => {
      const res = await fetch(apiPaths.myCourses({ view: 'nav' }));
      if (!res.ok) throw new Error('Failed to fetch courses');
      return (await res.json()) as Course[];
    },
    staleTime: 30_000,
  });

  const { state } = useSidebar();
  const collapsed = state === 'collapsed';

  if (!session?.user) return null;

  const {
    id = '',
    email = '',
    name = '',
    firstName = '',
    lastName = '',
    avatar = '',
    timezone,
    isAdmin = false,
  } = session.user;

  // Resolve display name and avatar
  const resolvedName =
    name ||
    [firstName, lastName].filter(Boolean).join(' ').trim() ||
    email?.split('@')[0] ||
    'User';
  const initials = (firstName?.[0] ?? '') + (lastName?.[0] ?? '') || resolvedName[0] || 'U';
  const avatarUrl = avatar?.trim() !== '' ? avatar : null;

  const user = {
    id,
    firstName: firstName,
    lastName: lastName,
    name: resolvedName,
    email,
    avatar: avatarUrl,
    timezone: timezone ?? null,
    initials,
    password: '', // password is not exposed from session
    temporaryPassword: Boolean(session.user.mustChangePassword),
    inactive: false, // inactive status is not exposed from session
    createdAt: new Date(), // createdAt is not exposed from session
    updatedAt: new Date(), // updatedAt is not exposed from session
  };

  // The server (nav API) already scopes which courses are returned per the
  // viewer's per-course role; here we only drop archived ones (they live on the
  // Archived Courses page), then bucket by date into the sidebar sections.
  const visibleCourses = courses.filter((c) => !c.isArchived);
  const courseSections = COURSE_SECTIONS.map((section) => ({
    ...section,
    courses: visibleCourses
      .filter((c) => getCourseDateBucket(c) === section.bucket)
      .sort((a, b) => a.code.localeCompare(b.code)),
  })).filter((section) => section.courses.length > 0);
  const isDev = process.env.NODE_ENV !== 'production';
  const resolvedAdminMenu = (
    isDev
      ? [
          ...adminMenu,
          { title: 'Development Tests', url: '/dashboard/development-tests', icon: Wrench },
        ]
      : adminMenu
  )
    .slice()
    .sort((a, b) => a.title.localeCompare(b.title));

  return (
    <>
      {/* Sidebar navigation content */}
      <SidebarContent>
        {/* Admin menu — system administrators only */}
        {isAdmin && (
          <SidebarGroup>
            <SidebarGroupLabel
              aria-hidden={collapsed}
              className={
                collapsed
                  ? 'hidden'
                  : 'text-sidebar-foreground overflow-hidden text-sm whitespace-nowrap'
              }
            >
              Admin Menu
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {resolvedAdminMenu.map(({ title, url, icon: Icon }) => (
                  <SidebarMenuItem key={url}>
                    <TooltipProvider delayDuration={100}>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <SidebarMenuButton
                            asChild
                            isActive={pathname === url}
                            className={cn(menuButtonStyles)}
                          >
                            <Link
                              href={url}
                              aria-label={title}
                              className="flex min-w-0 items-center gap-2"
                            >
                              <Icon className="h-4 w-4 shrink-0" />
                              <span
                                aria-hidden={collapsed}
                                className={
                                  collapsed
                                    ? 'hidden'
                                    : 'overflow-hidden text-ellipsis whitespace-nowrap'
                                }
                              >
                                {title}
                              </span>
                            </Link>
                          </SidebarMenuButton>
                        </TooltipTrigger>
                        <TooltipContent
                          side="right"
                          hidden={!collapsed}
                          className="bg-sidebar text-sidebar-foreground px-5 text-sm shadow"
                          sideOffset={10}
                        >
                          {title}
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {/* Course sections — bucketed by date; an empty section is omitted. */}
        {courseSections.length === 0
          ? !collapsed && (
              <SidebarGroup>
                <SidebarGroupContent>
                  <SidebarMenu>
                    <SidebarMenuItem>
                      <SidebarMenuButton
                        asChild
                        aria-disabled={true}
                        className={cn('text-sidebar-foreground/60 cursor-default')}
                      >
                        <div className={cn('flex w-full items-center gap-2')}>
                          <Book className="h-4 w-4 shrink-0" />
                          <span className="overflow-hidden text-ellipsis whitespace-nowrap">
                            No courses
                          </span>
                        </div>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            )
          : courseSections.map((section) => (
              <SidebarGroup key={section.bucket}>
                <SidebarGroupLabel
                  aria-hidden={collapsed}
                  className={
                    collapsed
                      ? 'hidden'
                      : 'text-sidebar-foreground overflow-hidden text-sm whitespace-nowrap'
                  }
                >
                  {section.label}
                </SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    {section.courses.map((course) => (
                      <SidebarMenuItem key={course.id}>
                        <TooltipProvider delayDuration={100}>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <SidebarMenuButton
                                asChild
                                isActive={pathname.startsWith(`/dashboard/courses/${course.id}`)}
                                className={cn(menuButtonStyles)}
                              >
                                <Link
                                  href={`/dashboard/courses/${course.id}`}
                                  aria-label={`${course.code}: ${course.name}`}
                                  className="flex min-w-0 items-center gap-2"
                                >
                                  <Book className="h-4 w-4 shrink-0" />
                                  <span
                                    aria-hidden={collapsed}
                                    className={
                                      collapsed
                                        ? 'hidden'
                                        : 'overflow-hidden text-ellipsis whitespace-nowrap'
                                    }
                                  >
                                    {course.code}
                                  </span>
                                </Link>
                              </SidebarMenuButton>
                            </TooltipTrigger>
                            <TooltipContent
                              side="right"
                              hidden={!collapsed}
                              className="bg-sidebar text-sidebar-foreground px-5 text-sm shadow"
                              sideOffset={10}
                            >
                              {course.code}
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            ))}

        {/* Features */}
        <SidebarGroup>
          <SidebarGroupLabel
            aria-hidden={collapsed}
            className={
              collapsed
                ? 'hidden'
                : 'text-sidebar-foreground overflow-hidden text-sm whitespace-nowrap'
            }
          >
            Other Pages
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem key="features-calendar">
                <TooltipProvider delayDuration={100}>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <SidebarMenuButton
                        asChild
                        isActive={pathname === '/dashboard/calendar'}
                        className={cn(menuButtonStyles)}
                      >
                        <Link
                          href="/dashboard/calendar"
                          aria-label="Calendar"
                          className="flex min-w-0 items-center gap-2"
                        >
                          <Calendar className="h-4 w-4 shrink-0" />
                          <span
                            aria-hidden={collapsed}
                            className={
                              collapsed
                                ? 'hidden'
                                : 'overflow-hidden text-ellipsis whitespace-nowrap'
                            }
                          >
                            Calendar
                          </span>
                        </Link>
                      </SidebarMenuButton>
                    </TooltipTrigger>
                    <TooltipContent
                      side="right"
                      hidden={!collapsed}
                      className="bg-sidebar text-sidebar-foreground px-5 text-sm shadow"
                      sideOffset={10}
                    >
                      Calendar
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </SidebarMenuItem>

              {/* Archived Courses */}
              <SidebarMenuItem key="features-archived-courses">
                <TooltipProvider delayDuration={100}>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <SidebarMenuButton
                        asChild
                        isActive={pathname === '/dashboard/archived-courses'}
                        className={cn(menuButtonStyles)}
                      >
                        <Link
                          href="/dashboard/archived-courses"
                          aria-label="Archived Courses"
                          className="flex min-w-0 items-center gap-2"
                        >
                          <Library className="h-4 w-4 shrink-0" />
                          <span
                            aria-hidden={collapsed}
                            className={
                              collapsed
                                ? 'hidden'
                                : 'overflow-hidden text-ellipsis whitespace-nowrap'
                            }
                          >
                            Archived Courses
                          </span>
                        </Link>
                      </SidebarMenuButton>
                    </TooltipTrigger>
                    <TooltipContent
                      side="right"
                      hidden={!collapsed}
                      className="bg-sidebar text-sidebar-foreground px-5 text-sm shadow"
                      sideOffset={10}
                    >
                      Archived Courses
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      {/* Footer menu for user account actions */}
      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <SidebarMenuButton className="hover:bg-secondary data-[state=open]:bg-secondary/70 data-[state=open]:text-secondary-foreground h-14 bg-[#525252] px-3 py-3 transition-colors">
                  <Avatar className="h-8 w-8 shrink-0">
                    <AvatarImage
                      src={user.avatar ? apiPaths.files.pfp(user.avatar) : undefined}
                      alt={user.name}
                    />
                    <AvatarFallback className="bg-secondary text-secondary-foreground text-xs">
                      {user.initials}
                    </AvatarFallback>
                  </Avatar>
                  {user.name}
                  <ChevronUp className="ml-auto" />
                </SidebarMenuButton>
              </DropdownMenuTrigger>
              <DropdownMenuContent side="top" className="w-[var(--radix-popper-anchor-width)]">
                <DropdownMenuItem>
                  <span className="flex w-full items-center gap-2 text-left">
                    <UserRound className="h-4 w-4" />
                    User Account
                  </span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <button
                    type="button"
                    className="flex w-full items-center gap-2 text-left"
                    onClick={() => setEditProfileOpen(true)}
                  >
                    <UserPen className="h-4 w-4" />
                    Edit Profile
                  </button>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <button
                    type="button"
                    className="flex w-full items-center gap-2 text-left"
                    onClick={() => setChangePasswordOpen(true)}
                  >
                    <LockKeyhole className="h-4 w-4" />
                    Change Password
                  </button>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <button
                    type="button"
                    className="flex w-full items-center gap-2 text-left"
                    onClick={() => void safeSignOut({ callbackUrl: '/' })}
                  >
                    <LogOut className="h-4 w-4" />
                    Sign out
                  </button>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>

      {/* Modals */}
      <ChangePasswordDialog
        open={changePasswordOpen}
        setOpen={setChangePasswordOpen}
        onChangePassword={async (oldPassword, newPassword) => {
          const res = await fetch(apiPaths.myPassword(), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ oldPassword, newPassword }),
          });
          if (!res.ok) {
            const { error } = await res.json();
            toast.error(error || 'Failed to change password');
            throw new Error(error || 'Failed to change password');
          }
          toast.success('Password changed!');
        }}
      />

      <EditProfileDialog user={user} open={editProfileOpen} setOpen={setEditProfileOpen} />
    </>
  );
}
