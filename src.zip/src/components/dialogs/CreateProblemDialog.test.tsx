/** @vitest-environment jsdom */

import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';

import { CreateProblemDialog } from './CreateProblemDialog';

vi.mock('@/components/ui/dialog', () => import('@/test/mocks/ui').then((mod) => mod.dialogMock));
vi.mock('@/components/ui/InputGroup', () =>
  import('@/test/mocks/ui').then((mod) => mod.inputGroupMock),
);
vi.mock('@/components/ui/switch', () => import('@/test/mocks/ui').then((mod) => mod.switchMock));
vi.mock('@/hooks/useMaxUploadSize', () => ({
  useMaxUploadSize: () => {
    // Mock the hook but don't call fetch in the hook
    return { maxMb: 25, loading: false, error: null };
  },
}));

const { showToastError } = vi.hoisted(() => ({
  showToastError: vi.fn(),
}));
vi.mock('@/lib/toast', () => ({
  showToast: {
    error: showToastError,
  },
}));

const globalWithReact = globalThis as typeof globalThis & { React?: typeof React };
globalWithReact.React = React;

const originalFetch = global.fetch;
const fetchMock = vi.fn();

describe('CreateProblemDialog', () => {
  beforeEach(() => {
    fetchMock.mockReset();
    global.fetch = fetchMock as unknown as typeof fetch;
  });

  afterEach(() => {
    global.fetch = originalFetch;
  });

  it('submits problem details and uploads the file', async () => {
    const user = userEvent.setup();
    const setOpen = vi.fn();
    const onCreated = vi.fn();

    // Must be valid XML/JFLAP content; the dialog rejects non-XML files.
    const fileContent = '<structure><type>FA</type></structure>';
    const file = new File([fileContent], 'answer.jff', { type: 'text/plain' });
    // jsdom's File doesn't implement text(); the dialog uses it to validate.
    Object.defineProperty(file, 'text', { value: () => Promise.resolve(fileContent) });

    fetchMock.mockImplementation((url: string) => {
      if (url.includes('/api/system-settings/public')) {
        return Promise.resolve({
          ok: true,
          json: async () => ({ maxUploadSizeMb: 25, sessionTimeoutMinutes: 20 }),
        } as Response);
      }
      return Promise.resolve({
        ok: true,
        json: async () => ({ id: 'prob-1' }),
      } as Response);
    });

    render(
      <CreateProblemDialog
        open
        setOpen={setOpen}
        courseId="course-1"
        courseIsArchived={false}
        onCreated={onCreated}
      />,
    );

    await user.type(screen.getByLabelText('Title'), 'DFA #1');
    // switch should exist and be checked by default
    expect(screen.getByLabelText('Automatically Graded')).toBeInTheDocument();
    expect(screen.getByLabelText('Automatically Graded')).toBeChecked();

    // Find and upload file using the file input ID
    const fileInput = document.getElementById('answer-file') as HTMLInputElement;
    if (fileInput) {
      await user.upload(fileInput, file);
    }

    // The file onChange validates asynchronously (reads the file text), so wait
    // for the form to become valid before submitting.
    const createButton = screen.getByRole('button', { name: 'Create Problem' });
    await waitFor(() => expect(createButton).toBeEnabled());
    await user.click(createButton);

    // Expect 1 call for problem creation (useMaxUploadSize is mocked and doesn't fetch)
    await waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(1));

    // Check the problem creation call (the only call)
    const [, requestInit] = fetchMock.mock.calls[0] as [string, RequestInit];
    expect(requestInit.method).toBe('POST');

    const formData = requestInit.body as FormData;
    const payload: Record<string, FormDataEntryValue> = {};
    formData.forEach((value, key) => {
      payload[key] = value;
    });

    expect(payload).toMatchObject({
      title: 'DFA #1',
      courseId: 'course-1',
    });
    // File may or may not be present depending on mock setup
    expect(onCreated).toHaveBeenCalledWith({ id: 'prob-1' }, true);
    expect(setOpen).toHaveBeenCalledWith(false);
  });

  it('prevents submission when the course is archived', async () => {
    const user = userEvent.setup();

    render(
      <CreateProblemDialog
        open
        setOpen={vi.fn()}
        courseId="course-1"
        courseIsArchived
        onCreated={vi.fn()}
      />,
    );

    await user.type(screen.getByLabelText('Title'), 'DFA #1');
    const fileInput = document.getElementById('answer-file') as HTMLInputElement;
    await user.upload(fileInput, new File(['test'], 'answer.jff'));

    expect(screen.getByRole('button', { name: 'Create Problem' })).toBeDisabled();
  });
});
