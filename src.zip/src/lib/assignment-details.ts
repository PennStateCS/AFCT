import type { Problem, CourseRole } from '@prisma/client';

export type AssignmentProblemLink = {
  problem: Problem;
  maxPoints: number;
  maxSubmissions: number;
  autograderEnabled: boolean;
};

export type AssignmentCourseSummary = {
  id: string;
  name: string;
  code?: string;
  isArchived?: boolean;
  /** The course's canonical timezone — anchors deadlines; used for dual-zone display. */
  timezone?: string | null;
  roster?: Array<{
    role: CourseRole | null;
    user: {
      id: string;
      firstName: string | null;
      lastName: string | null;
    };
  }>;
};

export type AssignmentWithDetails = {
  id: string;
  title: string;
  description?: string | null;
  courseId: string;
  courseName?: string;
  courseCode?: string;
  courseIsArchived?: boolean;
  dueDate: string | Date;
  maxPoints: number;
  allowLateSubmissions?: boolean;
  lateCutoff?: string | Date | null;
  isPublished: boolean;
  isGroup?: boolean;
  createdAt?: Date;
  updatedAt?: Date;
  problems: AssignmentProblemLink[];
  course?: AssignmentCourseSummary;
};

export type StudentProblemSubmission = {
  id: string;
  submittedAt: string;
  grade: number | null;
  feedback: string | null;
  problemId: string;
  status: string;
  fileName?: string | null;
  originalFileName?: string | null;
  correct?: boolean | null;
};

export type StudentProblemComment = {
  id: string;
  content: string;
  createdAt: string;
  authorId?: string | null;
  authorName: string;
  authorRole: CourseRole;
  problemId: string;
};

export type StudentAssignmentContext = {
  assignmentGrade: number | null;
  submissionCount: number;
  problemGrades: Record<string, number | null>;
  submissionsByProblem: Record<string, StudentProblemSubmission[]>;
  commentsByProblem: Record<string, StudentProblemComment[]>;
};
